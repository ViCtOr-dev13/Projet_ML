from urllib.parse import urlparse
import pandas as pd
import re
import os
from itertools import groupby
from collections import Counter
import math


def count_chars(s, chars):
    return sum(s.count(c) for c in chars)

def entropy(s):
    p, lns = Counter(s), float(len(s))
    return -sum( count/lns * math.log(count/lns, 2) for count in p.values())


def url_to_dataframe(url):
    

